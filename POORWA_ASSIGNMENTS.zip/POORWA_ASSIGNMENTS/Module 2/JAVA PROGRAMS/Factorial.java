public class Factorial
{
	public static void main(String ar[])
	{
		int i, fac = 1;
		int num = Integer.parseInt(ar[0]);
		for(i=1;i<=num;i++)
		{
			fac = fac * i;
		}
		System.out.println("Factorial of the number is: "+fac);
	}
}	