public class TestIfDemo
{
	public static void main(String ar[])
	{
		int marks = Integer.parseInt(ar[0]);
		
		if(marks<40)
		{
			System.out.println("You have failed");
		}
		
		else if((marks>=40) && (marks<60))
		{
			System.out.println("You have failed");
		}

		else if((marks>=60) && (marks<75))
		{
			System.out.println("You are first class");
		}

		else if((marks>=75) && (marks<100))
		{
			System.out.println("You got DISTICTION");
		}
		
		else
		System.out.println("Not valid");
	}
}	