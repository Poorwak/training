public class Average
{
	public static void main(String ar[])
	{
		float sum=0,avg=0;
		int i;
		
		for(i=0;i<10;i++)
		{
			sum = sum + Integer.parseInt(ar[i]);
		}
		avg = sum / 10;
		
		System.out.println("Average of numbers is: "+avg);
	}
}