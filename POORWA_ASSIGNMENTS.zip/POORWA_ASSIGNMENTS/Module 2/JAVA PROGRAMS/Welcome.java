public class Welcome
{
	public static void main(String ar[])

	{
		String firstName=ar[0];
		int sal=Integer.parseInt(ar[1]);
		System.out.println("Welcome to Capgemini "+firstName);
		System.out.println("Salary "+sal);
	}
}


class WishMe
{
	public static void main(String ar[])

	{
		String lastName="Kumbhaj";
		System.out.println("Happy New Year "+lastName);
	}
}