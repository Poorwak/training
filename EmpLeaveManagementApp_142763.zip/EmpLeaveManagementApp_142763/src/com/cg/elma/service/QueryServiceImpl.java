package com.cg.elma.service;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.elma.dao.IQueryDAO;
import com.cg.elma.dto.EmployeeDetails;
import com.cg.elma.dto.EmployeeLeaveDetails;

@Service("employeeservice")
@Transactional
public class QueryServiceImpl implements IQueryService
{
	@Autowired
	IQueryDAO employeedao;

	@Override
	public List<EmployeeLeaveDetails> retrieveEmployee(int id) 
	{
		return employeedao.retrieveEmployee(id);
	}

	@Override
	public List<EmployeeDetails> getempIds() 
	{
		return employeedao.getempIds();
	}

	@Override
	public List<EmployeeDetails> getIDs() 
	{
		return employeedao.getIDs();
	}

	@Override
	public boolean validateEIds(int empids) 
	{
		int count=0;
		Iterator it=employeedao.getempIds().iterator();
		
		while(it.hasNext())
		{
			int id=(int) it.next();
			
			if(empids==id)
			{
				count=1;			
				break;
			}
		}
		if(count==1)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}

	@Override
	public boolean validateEId(int empid) 
	{
		int count=0;
		Iterator it=employeedao.getIDs().iterator();
		
		while(it.hasNext())
		{
			int id=(int) it.next();
			
			if(empid==id)
			{
				count=1;
				break;
			}
		}
		if(count==1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

}
