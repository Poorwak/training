package com.cg.elma.service;

import java.util.List;

import com.cg.elma.dto.EmployeeDetails;
import com.cg.elma.dto.EmployeeLeaveDetails;

public interface IQueryService 
{
	public List<EmployeeLeaveDetails> retrieveEmployee(int id);
	public List<EmployeeDetails> getempIds();
	public List<EmployeeDetails> getIDs();
	public boolean validateEIds(int empids);
	public boolean validateEId(int empid);
}
