package com.cg.elma.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee_details")
public class EmployeeDetails 
{
	@Id
	@Column(name="empid")
	private Integer empId;
	
	@Column(name="ename")
	private String eName;
	
	@Column(name="address")
	private String eAddress;
	
	@Column(name="leaves_avail")
	private Integer leavesAvail;

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String geteName() {
		return eName;
	}

	public void seteName(String eName) {
		this.eName = eName;
	}

	public String geteAddress() {
		return eAddress;
	}

	public void seteAddress(String eAddress) {
		this.eAddress = eAddress;
	}

	public Integer getLeavesAvail() {
		return leavesAvail;
	}

	public void setLeavesAvail(Integer leavesAvail) {
		this.leavesAvail = leavesAvail;
	}
	
	
}
