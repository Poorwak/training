package com.cg.elma.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.elma.dto.EmployeeDetails;
import com.cg.elma.dto.EmployeeLeaveDetails;

@Repository("employeedao")
public class QueryDAOImpl implements IQueryDAO
{
	@PersistenceContext
	EntityManager entitymanager;
	
	@Override
	public List<EmployeeLeaveDetails> retrieveEmployee(int id) 
	{
		Query queryOne=entitymanager.createQuery("SELECT e FROM EmployeeLeaveDetails e WHERE empId=:eid");
		queryOne.setParameter("eid", id);
		return queryOne.getResultList();
	}

	@Override
	public List<EmployeeDetails> getempIds() 
	{
		Query queryTwo=entitymanager.createQuery("SELECT empId FROM EmployeeDetails");
		return queryTwo.getResultList();
	}

	@Override
	public List<EmployeeDetails> getIDs() 
	{
		Query queryThree=entitymanager.createQuery("SELECT empId FROM EmployeeLeaveDetails");
		return queryThree.getResultList();
	}
	
}
