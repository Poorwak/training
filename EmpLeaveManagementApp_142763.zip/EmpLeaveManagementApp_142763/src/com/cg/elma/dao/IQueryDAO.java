package com.cg.elma.dao;

import java.util.List;

import com.cg.elma.dto.EmployeeDetails;
import com.cg.elma.dto.EmployeeLeaveDetails;

public interface IQueryDAO 
{
	public List<EmployeeLeaveDetails> retrieveEmployee(int id);
	public List<EmployeeDetails> getempIds();
	public List<EmployeeDetails> getIDs();
	
}
