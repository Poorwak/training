package com.cg.elma.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.elma.dto.EmployeeLeaveDetails;
import com.cg.elma.service.IQueryService;


@Controller
public class QueryController 
{
	@Autowired
	private IQueryService employeeservice;
	
	public IQueryService getEmployeeservice() {
		return employeeservice;
	}

	public void setEmployeeservice(IQueryService employeeservice) {
		this.employeeservice = employeeservice;
	}

	@RequestMapping(value="home",method=RequestMethod.GET)
	public String getAll()
	{
		return "Home";
	}
	
	@RequestMapping(value="search",method=RequestMethod.GET)
	public ModelAndView viewEmployee(@ModelAttribute("emp") EmployeeLeaveDetails empleave, @RequestParam("empId") int empid) 
	{
		if (employeeservice.validateEIds(empid)==true)
		{
			if(employeeservice.validateEId(empid)==true)
			{
				List<EmployeeLeaveDetails> srchData=employeeservice.retrieveEmployee(empid);
				return new ModelAndView("viewLeaveDetails","srchData",srchData);
			}
			else
			{
				return new ModelAndView("Failure");
			}
		}
		else
		{
			return new ModelAndView("myError");
		}
		
//		List<EmployeeLeaveDetails> srchData =employeeservice.retrieveEmployee(empid);
//		ModelAndView mv=new ModelAndView();
//		
//		if (srchData!= null) 
//		{
//			mv.setViewName("viewLeaveDetails");
//			mv.addObject("srchData", srchData);
//		} 
//		else 
//		{
//			String msg = "Enter a Valid Employee Id";
//			mv.setViewName("myError");
//			mv.addObject("msg", msg);
//		}
//
//		return mv;
	}
}
