package com.cg.service;

import com.cg.dto.Employee;

public interface IEmployeeService 
{
	public Employee getEmployeeDetails(int empId);
}
