package com.cg.service;

import com.cg.dao.IEmployeeDao;
import com.cg.dto.Employee;

public class IEmployeeServiceImpl 
{
	IEmployeeDao eDao;

	public IEmployeeDao geteDao() {
		return eDao;
	}

	public void seteDao(IEmployeeDao eDao) {
		this.eDao = eDao;
	}
	
	public Employee getEmployeeDetails(int empId)
	{
		return eDao.getEmployeeDetails(empId);
	}
}
