package com.cg.dao;

import java.util.List;

import com.cg.dto.Employee;

public class IEmployeeDaoImpl implements IEmployeeDao
{
	List <Employee> emp;
			
	public List<Employee> getEmp() {
		return emp;
	}

	public void setEmp(List<Employee> emp) {
		this.emp = emp;
	}

	@Override
	public Employee getEmployeeDetails(int empId) 
	{
		Employee ee=null;
		
		for(Employee e:emp)
		{
			if(e.getEmpId()==empId)
			{
				ee=e;
			}
			else
			{
				;
			}
		}
		return ee;
	}

}
