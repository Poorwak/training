package com.cg.labtwo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.labtwo.dto.Trainee;
import com.cg.labtwo.service.ITraineeService;

@Controller
public class TraineeController 
{
	@Autowired
	ITraineeService traineeservice;
	
	@RequestMapping(value="login",method=RequestMethod.GET)
	public String getAll()
	{
		return "loginpage";
	}
	
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String operations(@RequestParam("Username")String uname, @RequestParam("Password")String pwd) 			
	{
		if(uname.equals("admin") && pwd.equals("admin"))
		{
			return "traineeoperations";
		}
		else
		{
			return "failure";
		}
		
	}
	
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addTrainee(@ModelAttribute("my") Trainee trn, Map<String,Object> model) 			//linking jsp to dto
	{
		List<String> myDom=new ArrayList<>();
		myDom.add("JEE");
		myDom.add("Oracle");
		myDom.add("VNV");
		myDom.add("IMS");
		model.put("dom",myDom);		
		return "addTrainee";
	}
	
	@RequestMapping(value="insertdata",method=RequestMethod.POST)
	public ModelAndView addTrainee(@Valid@ModelAttribute("my") Trainee trn, BindingResult result, Map<String,Object> model) 			//linking jsp to dto
	{
		int id=0;
		if(result.hasErrors())
		{
			List<String> myDom=new ArrayList<>();
			myDom.add("JEE");
			myDom.add("Oracle");
			myDom.add("VNV");
			myDom.add("IMS");
			model.put("dom",myDom);		
			return new ModelAndView("addTrainee");
		}
		else
		{
			id=traineeservice.addTrainee(trn);
		}
		return new ModelAndView("traineeoperations","edata",id);
		
	}
	
	@RequestMapping(value="delete", method=RequestMethod.GET)
	public String deleteTrainee()
	{
		return "deletetrainee";
	}
	
	@RequestMapping(value="dodelete", method=RequestMethod.GET)
	public ModelAndView retrievetrainee(@RequestParam("tid") int id) 		
	{
		List<Trainee> myData =traineeservice.retrieveTrainee(id);
		//traineeservice.deleteTrainee(id);
		return new ModelAndView("deletetrainee","del",myData);
	}
	
	@RequestMapping(value="delete1", method=RequestMethod.GET)
	public String traineeDelete1(@RequestParam("tid") int id) 		
	{
		traineeservice.deleteTrainee(id);
		//System.out.println("done.....");
		return "traineeoperations";
	}
	
	@RequestMapping(value="search", method=RequestMethod.GET)
	public String searchTrainee()
	{
		return "searchTrainee";
	}
	
	@RequestMapping(value="dosearch", method=RequestMethod.GET)
	public ModelAndView traineeSearch(@RequestParam("tid") int trnid)
	{
		List<Trainee> srchData =traineeservice.retrieveTrainee(trnid);
		return new ModelAndView("searchTrainee","srch",srchData);
	}
	
	@RequestMapping(value="searchAll", method=RequestMethod.GET)
	public  ModelAndView searchAllTrainee()
	{
		List<Trainee> srchAllData =traineeservice.searchAllTrainee();
		return new ModelAndView("searchAllTrainee","srchAll",srchAllData);
	}
	
	@RequestMapping(value="modify", method=RequestMethod.GET)
	public String modifyTrainee()
	{
		return "modifytrainee";
	}
	
	@RequestMapping(value="doupdate", method=RequestMethod.GET)
	public ModelAndView updateTrainee(@RequestParam("tid") int trnid,
			@ModelAttribute("me") Trainee trn)
	{
		List<Trainee> myData = traineeservice.searchTrainee(trnid);
		return new ModelAndView("modifytrainee","del",myData);
		
	}
	@RequestMapping(value="update1", method=RequestMethod.GET)
	public String traineeUpdate(@ModelAttribute("me") Trainee trn)
	{
		traineeservice.updateTrainee(trn);
		return "success";
	}
	
}
