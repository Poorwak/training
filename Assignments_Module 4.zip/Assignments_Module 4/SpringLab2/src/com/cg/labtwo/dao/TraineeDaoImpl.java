package com.cg.labtwo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.labtwo.dto.Trainee;

@Repository("traineedao")
public class TraineeDaoImpl implements ITraineeDao
{
	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public int addTrainee(Trainee trn) 
	{
		entitymanager.persist(trn);
		entitymanager.flush();
		return trn.getTraineeId();
	}
	
	@Override
	public void deleteTrainee(int traineeId) 
	{
		Query queryOne=entitymanager.createQuery("DELETE FROM Trainee WHERE traineeId=:id");
		queryOne.setParameter("id", traineeId);
		queryOne.executeUpdate();
	}
	
	@Override
	public List<Trainee> retrieveTrainee(int id) 
	{
		Query queryTwo=entitymanager.createQuery("SELECT t FROM Trainee t WHERE traineeId=:tid");
		queryTwo.setParameter("tid", id);
		return queryTwo.getResultList();
	}

	@Override
	public List<Trainee> searchTrainee(int trnid) 
	{
		Query queryThree=entitymanager.createQuery("SELECT t FROM Trainee t WHERE traineeId=:tid");
		queryThree.setParameter("tid", trnid);
		return queryThree.getResultList();
	}

	@Override
	public List<Trainee> searchAllTrainee() 
	{
		Query queryFour=entitymanager.createQuery("FROM Trainee");
		return queryFour.getResultList();
	}

	@Override
	public void updateTrainee(Trainee trn)
	{
		Query queryfive=entitymanager.createQuery("UPDATE Trainee set traineeName=:tname,"
													+"traineeLocation=:tloc,"
													+"traineeDomain=:tdom WHERE traineeId=:tid");
		queryfive.setParameter("tid", trn.getTraineeId());
		queryfive.setParameter("tname", trn.getTraineeName());
		queryfive.setParameter("tloc", trn.getTraineeLocation());
		queryfive.setParameter("tdom", trn.getTraineeDomain());
		queryfive.executeUpdate();
	}

}
