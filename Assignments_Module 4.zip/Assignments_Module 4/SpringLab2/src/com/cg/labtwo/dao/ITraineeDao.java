package com.cg.labtwo.dao;

import java.util.List;

import com.cg.labtwo.dto.Trainee;

public interface ITraineeDao 
{
	public int addTrainee(Trainee trn);
	public void deleteTrainee(int traineeId);
	public List<Trainee> retrieveTrainee(int id);
	public List<Trainee> searchTrainee(int trnid); 
	public List<Trainee> searchAllTrainee();
	public void updateTrainee(Trainee trn);
	
}
