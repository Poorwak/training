package com.cg.labtwo.service;

import java.util.List;

import com.cg.labtwo.dto.Trainee;


public interface ITraineeService 
{
	public int addTrainee(Trainee trn);
	public void deleteTrainee(int traineeId);
	public List<Trainee> retrieveTrainee(int id);
	public List<Trainee> searchTrainee(int trnid);
	public List<Trainee> searchAllTrainee();
	public void updateTrainee(Trainee trn);
}
