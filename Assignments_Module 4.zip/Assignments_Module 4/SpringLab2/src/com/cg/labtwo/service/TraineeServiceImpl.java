package com.cg.labtwo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.labtwo.dao.ITraineeDao;
import com.cg.labtwo.dto.Trainee;

@Service("traineeservice")
@Transactional
public class TraineeServiceImpl implements ITraineeService
{
	@Autowired
	ITraineeDao traineedao;
	
	@Override
	public int addTrainee(Trainee trn) 
	{
		
		return traineedao.addTrainee(trn);
	}

	@Override
	public void deleteTrainee(int traineeId) 
	{
		traineedao.deleteTrainee(traineeId);
	}

	@Override
	public List<Trainee> retrieveTrainee(int id)
	{
		return traineedao.retrieveTrainee(id);
	}

	@Override
	public List<Trainee> searchTrainee(int trnid) 
	{
		return traineedao.searchTrainee(trnid);
	}

	@Override
	public List<Trainee> searchAllTrainee() 
	{
		return traineedao.searchAllTrainee();
	}

	@Override
	public void updateTrainee(Trainee trn) 
	{
		traineedao.updateTrainee(trn);
		
	}

}
