package com.cg.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.dto.Employee;

public class MyTest
{
	public static void main(String[] args)
	{
		ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");
		Employee emp=(Employee) app.getBean("emp");
		emp.getAllDetails();
	}
}
