package com.cg.dto;

public class EmployeeBean 
{
	int employeeId;
	String employeeName;
	Double salary;
	SBUBean businessUnit;
	int age;
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public SBUBean getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(SBUBean businessUnit) {
		this.businessUnit = businessUnit;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	
	public void getSbuDetails() 
	{
		System.out.println("Employee details");
		System.out.println("----------------------");
		System.out.println("EmployeeBean [employeeId=" + employeeId + ", employeeName="
				+ employeeName + ", salary=" + salary + ", age= "+age + "\nsbu Details="
				+ businessUnit.getSbuDetails() + "]");
		
		
	}	
}
